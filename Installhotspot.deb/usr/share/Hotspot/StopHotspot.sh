#!/bin/bash

pasta_hotspot=/usr/share/Hotspot
service hostapd stop
service dnsmasq stop
echo -e "Hotspot\033[31;1m parado\033[0m..." > $pasta_hotspot/hotspot.conf

exit 0
