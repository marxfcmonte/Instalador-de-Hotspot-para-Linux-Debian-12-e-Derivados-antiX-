#!/bin/bash

display_principal(){
	cont="$[${#texto} + 4]"
	dialog --title "$titulo" --infobox "$texto" 3 $cont
	sleep 2
	clear
}

input_principal(){
	cont="$[${#texto} + 14]"
	nome=$(dialog --inputbox "$texto" 8 $cont --stdout)
	validacao="$?"
	clear
}

cancelar_principal(){
	if [ "$validacao" = "1" ]; then
		texto="Cancelado pelo usuário."
		display_principal
		sudo chown root:root /etc/hostapd/hostapd.conf
		sudo service hostapd start
		sudo service dnsmasq start
		exit 0
	fi
}

pasta_hotspot=/usr/share/Hotspot
while true
do
	senha=$(dialog --title "AUTORIZAÇÃO" --passwordbox "Digite a senha (SUDO):" 8 40 --stdout)
	validacao="$?"
	cancelar_principal
	if [ -z "$senha" ]; then
		dialog --colors --title "\Zr\Z1  ERRO                               \Zn" --infobox "A senha (SUDO) não foi digitada." 3 37
		sleep 2
		clear
	else
		break
	fi
done
clear
host="$(echo $senha|sudo -S -p "" service hostapd status)"
dns="$(sudo service dnsmasq status)"
if ! [ "$(echo "$host" | grep "not running")" ]; then
	sudo service hostapd stop
fi
if [ "$(echo "$dns" | grep running)" ]; then
	sudo service dnsmasq stop
fi
sudo chown $USER:$USER /etc/hostapd/hostapd.conf
sudo sed -i 's#^DAEMON_CONF=.*#DAEMON_CONF=/etc/hostapd/hostapd.conf#' /etc/init.d/hostapd
sudo ifconfig wlan0 up
sudo ifconfig wlan0 192.168.137.1/24
sudo iptables -t nat -F
sudo iptables -F
sudo iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
sudo iptables -A FORWARD -i wlan0 -o eth0 -j ACCEPT
sudo echo '1' > /proc/sys/net/ipv4/ip_forward
clear
while true
do
	texto="Nome da rede Wi-Fi (SSID)"
	input_principal
	cancelar_principal
	rede=$nome
	if [ -z "$rede" ]; then
		texto="Nome da rede Wi-Fi (SSID) não informado."
		display_principal
	else
		break
	fi
done
while true
do
	texto="Senha da rede Wi-Fi"
	input_principal
	cancelar_principal
	senha=$nome
	if [ -z "$senha" ]; then
		texto="Senha da rede Wi-Fi não informada."
		display_principal
	else
		break
	fi
done
cat <<EOF > /etc/hostapd/hostapd.conf
interface=wlan0
driver=nl80211
channel=1

ssid=$rede
wpa=2
wpa_passphrase=$senha
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
# Altera as chaves transmitidas/multidifundidas 
# após esse número de segundos.
wpa_group_rekey=600
# Troca a chave mestra após esse número de segundos.
# A chave mestra é usada como base.
wpa_gmk_rekey=86400

EOF

sudo chown root:root /etc/hostapd/hostapd.conf
sudo service hostapd start
sudo service dnsmasq start
echo -e "Hotspot\033[32;1m reiniciado\033[0m..." > $pasta_hotspot/hotspot.conf
reset

exit 0
