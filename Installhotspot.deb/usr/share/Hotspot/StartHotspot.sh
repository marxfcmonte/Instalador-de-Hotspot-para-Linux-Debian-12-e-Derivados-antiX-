#!/bin/bash

pasta_hotspot=/usr/share/Hotspot
host="$(service hostapd status)"
dns="$(service dnsmasq status)"
if ! [ "$(echo "$host" | grep "not running")" ]; then
	service hostapd stop
fi
if [ "$(echo "$dns" | grep running)" ]; then
	service dnsmasq stop
fi
sed -i 's#^DAEMON_CONF=.*#DAEMON_CONF=/etc/hostapd/hostapd.conf#' /etc/init.d/hostapd
ifconfig wlan0 up
ifconfig wlan0 192.168.137.1/24
iptables -t nat -F
iptables -F
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
iptables -A FORWARD -i wlan0 -o eth0 -j ACCEPT
echo '1' > /proc/sys/net/ipv4/ip_forward
service hostapd start
service dnsmasq start
echo -e "Hotspot\033[32m iniciado\033[0m..." > $pasta_hotspot/hotspot.conf

exit 0
