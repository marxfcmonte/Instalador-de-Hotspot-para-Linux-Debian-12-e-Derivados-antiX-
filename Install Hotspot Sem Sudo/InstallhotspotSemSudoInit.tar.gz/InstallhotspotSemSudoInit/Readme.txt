Execute o arquivo "InstallHotspotSemSudoInit.sh" com "./InstallHotspotSemSudoInit.sh", 
quando for solicitado a senha do "sudo", insira.

O executável instalará as dependências necessárias.
